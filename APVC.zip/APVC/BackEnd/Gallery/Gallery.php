<!DOCTYPE html>
<html lang="en-us">
   <head>
      <meta charset="utf-8">
      <title>Lightbox Example</title>
      <link rel="stylesheet" href="dist/css/lightbox.min.css">
      <!-- Panels -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
      <!-- Table and Image -->
      <style>
         table, td, th {
         border: 1px solid black;
         }
         table.center {
         margin-left:auto; 
         margin-right:auto;
         }
         img {
         border: 1px solid #ddd;
         padding: 2px;
         width: 80px;
         height: 80px;
         }
      </style>
<!-- END TaBLE -->

<!-- Bootstrap core CSS -->
<link href="../layout/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<link href="../layout/assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">
<!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
<!--[if lt IE 9]><script src="layout/assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
<script src="../layout/assets/js/ie-emulation-modes-warning.js"></script>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
<!-- Custom styles for this template -->
<link href="../layout/carousel.css" rel="stylesheet">
</head>
   <body>
      <div class="navbar-wrapper">
         <div class="container">
            <nav class="navbar navbar-inverse navbar-static-top">
               <div class="container">
                  <div class="navbar-header">
                     <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                     <span class="sr-only">Toggle navigation</span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     </button>
                     <a class="navbar-brand" href="#">Vila do Coronado</a>
                  </div>
                  <div id="navbar" class="navbar-collapse collapse">
                     <ul class="nav navbar-nav">
                        <li><a href="../index.php">APVC</a></li>
                        <li><a href="About/About.php">Quem Somos?</a></li>
                        <li class="active"><a href="Gallery.php">Galeria</a></li>
                        <li class="dropdown">
                           <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
                           <ul class="dropdown-menu">
                              <li><a href="#">Socio</a></li>
                              <li><a href="#">Localização</a></li>
                              <li><a href="#">Something else here</a></li>
                              <li role="separator" class="divider"></li>
                              <li class="dropdown-header">Nav header</li>
                              <li><a href="#">Separated link</a></li>
                              <li><a href="#">One more separated link</a></li>
                           </ul>
                        </li>
                     </ul>
                  </div>
               </div>
            </nav>
         </div>
      </div>
      <!-- Carousel
         ================================================== -->
      <div id="myCarousel" class="carousel slide" data-ride="carousel">
         <!-- Indicators -->
         <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
         </ol>
         <div class="carousel-inner" role="listbox">
            <div class="item active">
               <img class="first-slide" src="data:image/gif;base64,R0lGODlhAQABAIAAAHd3dwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==" alt="First slide">
               <div class="container">
                  <div class="carousel-caption">
                     <h1>Example headline.</h1>
                     <p>Note: If you're viewing this page via a <code>file://</code> URL, the "next" and "previous" Glyphicon buttons on the left and right might not load/display properly due to web browser security rules.</p>
                     <p><a class="btn btn-lg btn-primary" href="#" role="button">Sign up today</a></p>
                  </div>
               </div>
            </div>
            <div class="item">
               <img class="second-slide" src="data:image/gif;base64,R0lGODlhAQABAIAAAHd3dwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==" alt="Second slide">
               <div class="container">
                  <div class="carousel-caption">
                     <h1>Another example headline.</h1>
                     <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                     <p><a class="btn btn-lg btn-primary" href="#" role="button">Learn more</a></p>
                  </div>
               </div>
            </div>
            <div class="item">
               <img class="third-slide" src="data:image/gif;base64,R0lGODlhAQABAIAAAHd3dwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==" alt="Third slide">
               <div class="container">
                  <div class="carousel-caption">
                     <h1>One more for good measure.</h1>
                     <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                     <p><a class="btn btn-lg btn-primary" href="#" role="button">Browse gallery</a></p>
                  </div>
               </div>
            </div>
         </div>
         <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
         <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
         <span class="sr-only">Previous</span>
         </a>
         <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
         <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
         <span class="sr-only">Next</span>
         </a>
      </div>
      <!-- /.carousel -->

      <div class="container">
         <div class="panel-group">
            <!-- First Event-->
            <div class="panel panel-info">
               <div class="panel-heading">
                  <!-- GET Title (Event 0)-->
                  <?PHP
                      include '../../FrontEnd/Conn/conn.php';
                      $sql    = "Select Title from Event_V0 where 1=1";
                      $result = $conn->query($sql);
                      if ($result->num_rows > 0) {
                      while ($row = $result->fetch_assoc()) {
                        print $Title=$row['Title'];}
                  }?> 
               </div>
               <div class="panel-body">
                  <div align="left" class="panel panel-default">
                     <div class="panel-heading">
                     <!-- GET Title (Event 0)-->
                      <?PHP
                        include '../../FrontEnd/Conn/conn.php';
                        $sql    = "Select Title from Event_V0 where 1=1";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                          print $Title=$row['Title'];}
                      }?> 
                     </div>
                     <div class="panel-body">   
                     <?PHP
                      //GET Description (Event 0)
                      include '../../FrontEnd/Conn/conn.php';
                      $sql    = "Select Description from Event_V0 where 1=1";
                      $result = $conn->query($sql);
                      if ($result->num_rows > 0) {
                      while ($row = $result->fetch_assoc()) {
                        print $Description=$row['Description'];}
                      }?> 
                     </div>
                  </div>
                  <br>
                  <table class="center">
                     <!-- First -->
                     <tr>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v0/File_v0/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                         <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v0/File_v1/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v0/File_v2/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v0/File_v3/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v0/File_v4/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                     </tr>
                     <!-- Second -->
                     <tr>
                      <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v0/File_v5/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v0/File_v6/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v0/File_v7/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v0/File_v8/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v0/File_v9/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                     </tr>
                     <!-- Third -->
                     <tr>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v0/File_v10/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v0/File_v11/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v0/File_v12/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v0/File_v13/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v0/File_v14/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                     </tr>
                  </table>
               </div>
            </div>
         </div>
        
                    <!-- Second Event-->
            <div class="panel panel-primary">
               <div class="panel-heading">
                  <!-- GET Title (Event 0)-->
                  <?PHP
                      include '../../FrontEnd/Conn/conn.php';
                      $sql    = "Select Title from Event_V1 where 1=1";
                      $result = $conn->query($sql);
                      if ($result->num_rows > 0) {
                      while ($row = $result->fetch_assoc()) {
                        print $Title=$row['Title'];}
                  }?> 
               </div>
               <div class="panel-body">
                  <div align="left" class="panel panel-default">
                     <div class="panel-heading">
                     <!-- GET Title (Event 0)-->
                      <?PHP
                        include '../../FrontEnd/Conn/conn.php';
                        $sql    = "Select Title from Event_V1 where 1=1";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                          print $Title=$row['Title'];}
                      }?> 
                     </div>
                     <div class="panel-body">   
                     <?PHP
                      //GET Description (Event 0)
                      include '../../FrontEnd/Conn/conn.php';
                      $sql    = "Select Description from Event_V1 where 1=1";
                      $result = $conn->query($sql);
                      if ($result->num_rows > 0) {
                      while ($row = $result->fetch_assoc()) {
                        print $Description=$row['Description'];}
                      }?> 
                     </div>
                  </div>
                  <br>
                  <table class="center">
                     <!-- First -->
                     <tr>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v1/File_v0/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                         <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v1/File_v1/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v1/File_v2/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v1/File_v3/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v1/File_v4/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                     </tr>
                     <!-- Second -->
                     <tr>
                      <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v1/File_v5/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v1/File_v6/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v1/File_v7/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v1/File_v8/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v1/File_v9/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                     </tr>
                     <!-- Third -->
                     <tr>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v1/File_v10/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v1/File_v11/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v1/File_v12/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v1/File_v13/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v1/File_v14/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                     </tr>
                  </table>
               </div>
            </div>
            
            <!-- Third Event-->
            <div class="panel panel-danger">
               <div class="panel-heading">
                  <!-- GET Title (Event 0)-->
                  <?PHP
                      include '../../FrontEnd/Conn/conn.php';
                      $sql    = "Select Title from Event_V2 where 1=1";
                      $result = $conn->query($sql);
                      if ($result->num_rows > 0) {
                      while ($row = $result->fetch_assoc()) {
                        print $Title=$row['Title'];}
                  }?> 
               </div>
               <div class="panel-body">
                  <div align="left" class="panel panel-default">
                     <div class="panel-heading">
                     <!-- GET Title (Event 0)-->
                      <?PHP
                        include '../../FrontEnd/Conn/conn.php';
                        $sql    = "Select Title from Event_V2 where 1=1";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                          print $Title=$row['Title'];}
                      }?> 
                     </div>
                     <div class="panel-body">   
                     <?PHP
                      //GET Description (Event 0)
                      include '../../FrontEnd/Conn/conn.php';
                      $sql    = "Select Description from Event_V2 where 1=1";
                      $result = $conn->query($sql);
                      if ($result->num_rows > 0) {
                      while ($row = $result->fetch_assoc()) {
                        print $Description=$row['Description'];}
                      }?> 
                     </div>
                  </div>
                  <br>
                  <table class="center">
                     <!-- First -->
                     <tr>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v2/File_v0/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                         <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v2/File_v1/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v2/File_v2/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v2/File_v3/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v2/File_v4/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                     </tr>
                     <!-- Second -->
                     <tr>
                      <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v2/File_v5/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v2/File_v6/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v2/File_v7/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v2/File_v8/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v2/File_v9/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                     </tr>
                     <!-- Third -->
                     <tr>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v2/File_v10/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v2/File_v11/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v2/File_v12/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v2/File_v13/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v2/File_v14/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                     </tr>
                  </table>
               </div>
            </div>
                        <!-- Second Event-->
            <div class="panel panel-success">
               <div class="panel-heading">
                  <!-- GET Title (Event 0)-->
                  <?PHP
                      include '../../FrontEnd/Conn/conn.php';
                      $sql    = "Select Title from Event_V3 where 1=1";
                      $result = $conn->query($sql);
                      if ($result->num_rows > 0) {
                      while ($row = $result->fetch_assoc()) {
                        print $Title=$row['Title'];}
                  }?> 
               </div>
               <div class="panel-body">
                  <div align="left" class="panel panel-default">
                     <div class="panel-heading">
                     <!-- GET Title (Event 0)-->
                      <?PHP
                        include '../../FrontEnd/Conn/conn.php';
                        $sql    = "Select Title from Event_V3 where 1=1";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                          print $Title=$row['Title'];}
                      }?> 
                     </div>
                     <div class="panel-body">   
                     <?PHP
                      //GET Description (Event 0)
                      include '../../FrontEnd/Conn/conn.php';
                      $sql    = "Select Description from Event_V3 where 1=1";
                      $result = $conn->query($sql);
                      if ($result->num_rows > 0) {
                      while ($row = $result->fetch_assoc()) {
                        print $Description=$row['Description'];}
                      }?> 
                     </div>
                  </div>
                  <br>
                  <table class="center">
                     <!-- First -->
                     <tr>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v3/File_v0/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                         <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v3/File_v1/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v3/File_v2/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v3/File_v3/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v3/File_v4/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                     </tr>
                     <!-- Second -->
                     <tr>
                      <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v3/File_v5/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v3/File_v6/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v3/File_v7/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v3/File_v8/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v3/File_v9/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                     </tr>
                     <!-- Third -->
                     <tr>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v3/File_v10/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v3/File_v11/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                        <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v3/File_v12/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v3/File_v13/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                         <td>
                          <?php
                            $files = glob("../../FrontEnd/Main/MProject/Framework/upload_events/event_v3/File_v14/*.*");
                            for ($i = 0; $i < count($files); $i++) {$image = $files[$i];
                              print " <a class=\"example-image-link\" href=$image data-lightbox=\"example-set\" data-title=\"Or press the right arrow on your keyboard.\"><img class=\"example-image\" src=$image  alt=\"APVC\" /></a>\n";}?>
                        </td>
                     </tr>
                  </table>
               </div>
            </div>
         </div>
         </div>
         </div>


         
               </table>
            </div>
         </div>
      </div>
      </div>
      </div>
      <!-- FOOTER -->
      <footer>
         <p class="pull-right"><a href="#">Back to top</a></p>
         <p>&copy; 2016 Company, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
      </footer>
      </div><!-- /.container -->
      <!-- Bootstrap core JavaScript
         ================================================== -->
      <script src="dist/js/lightbox-plus-jquery.min.js"></script>
      <!-- Placed at the end of the document so the pages load faster -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
      <script>window.jQuery || document.write('<script src="layout/assets/js/vendor/jquery.min.js"><\/script>')</script>
      <script src="layout/dist/js/bootstrap.min.js"></script>
      <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
      <script src="layout/assets/js/vendor/holder.min.js"></script>
      <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
      <script src="layout/assets/js/ie10-viewport-bug-workaround.js"></script>
   </body>
</html>