function initMap() {

	var broadway = {
		info: '<strong>São Mamede Do Coronado</strong><br>\
					Rua Vale do Coronado - Trofa, Código Postal de 4745-417<br>\
					<a href="https://www.google.pt/maps/place/S%C3%A3o+Mamede+do+Coronado,+Trofa/@41.2764373,-8.5730599,17z/data=!3m1!4b1!4m5!3m4!1s0xd2460aca2e4c5b1:0xbe8a914bc9ff40d6!8m2!3d41.2764373!4d-8.5708712">Get Directions</a>',
		lat: 41.2764373,
		long: -8.5730599
	};

	var locations = [
      [broadway.info, broadway.lat, broadway.long, 0],

    ];

	var map = new google.maps.Map(document.getElementById('map'), {
		zoom: 13,
		center: new google.maps.LatLng(41.2764373,-8.5730599),
		mapTypeId: google.maps.MapTypeId.ROADMAP
	});

	var infowindow = new google.maps.InfoWindow({});

	var marker, i;

	for (i = 0; i < locations.length; i++) {
		marker = new google.maps.Marker({
			position: new google.maps.LatLng(locations[i][1], locations[i][2]),
			map: map
		});

		google.maps.event.addListener(marker, 'click', (function (marker, i) {
			return function () {
				infowindow.setContent(locations[i][0]);
				infowindow.open(map, marker);
			}
		})(marker, i));
	}
}
