<?php
include '../../../Conn/Conn.php';
// Getting Username

$Username = $_GET['Username'];
    //Insert New record
    $removerecord = "DELETE FROM Login WHERE Username=$Username";

    if ($conn->query($removerecord) === TRUE) {
        echo "<script>alert(\"The user has been removed.\")</script>";
        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../InfoAdmin/InfoAdmin.php\";
        }redireciona();
        </script>";
    } else 
    {
        echo "<script>alert(\"The user not has been  removed.\")</script>";
        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../InfoAdmin/InfoAdmin.php\";
        }redireciona();
        </script>";
    }

?> 



