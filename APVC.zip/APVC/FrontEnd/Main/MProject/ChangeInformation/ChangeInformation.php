<?PHP include '../../../Conn/Session_ChangeInformation.php';?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
		 <title>APVC</title>
    <title>Justified Nav Template for Bootstrap</title>

    <!-- Bootstrap core CSS -->
    <link href="../../Layout/css/dist/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../../Layout/css/assets/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="justified-nav.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../Layout/js/assets/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

     <!-- Panel -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!--Panel -->

  </head>
  <body>
    <div class="container">
      <!-- The justified navigation menu is meant for single line per list item.
           Multiple lines will require custom code not provided by Bootstrap. -->
      <div class="masthead">
        <h3 class="text-muted">APVC</h3>
        <nav>
          <ul class="nav nav-justified">
            <li><a href="../index.php">Home</a></li>
            <li><a href="../InfoAdmin/InfoAdmin.php">InfoAdmin</a></li>
            <li><a href="../PaymentControl/PaymentControl.php">PaymentControl</a></li>
            <li><a href="../Partner/Partner.php">Partner</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
        </nav>
      </div>
<br>
    </div>
  </div>
</div>
<br>
<div align="center"><img src="../../Images/Preloader_3.gif" alt="HTML5 Icon" width="75" height="75"/></div>
 <!-- Panel -->
<div class="container">
  <div class="panel-group">
        <div class="container">
          <h2>Change Information</h2>
          <div class="panel-group" id="accordion">
          <!--Change Password -->
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title">
                  <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">Change Password</a>
                </h4>
              </div>
              <div id="collapse1" class="panel-collapse collapse in">
                <div class="panel-body">
                  <form align="center" method="post" action='CheckPassword.php'>
          <div class="panel panel-primary">
          <div class="panel-heading">Change Password</div>
          <br>
          <div class="input-group">
            <span class="input-group-addon" id="basic-addon1"><img src="../../Images/Letter.png" alt="HTML5 Icon" width="15" height="15"/></span>
              <input type="text" class="form-control" width="35" height="35" name="Username" placeholder="Current Username" aria-describedby="basic-addon1">
            <span class="input-group-addon" id="basic-addon1"><img src="../../Images/Password.png" alt="HTML5 Icon" width="15" height="15"/></span>
              <input type="password" class="form-control" width="35" height="35" name="currentPassword"placeholder="Current Password" aria-describedby="basic-addon1">
            <span class="input-group-addon" id="basic-addon1"><img src="../../Images/NewPassword.jpg" alt="HTML5 Icon" width="15" height="15"/></span>
            <input type="password" class="form-control" width="35" height="35" name="newpassword" placeholder="New Password" aria-describedby="basic-addon1">
          </div>
          <br>
          <button class="btn btn-primary" type="sumbit">Change Password</button>
          <button class="btn btn-primary" type="reset">Clear Fields</button>
          <br>
            <br>
          </form>
                </div>
              </div>
            </div>

<!--Change Secret Password -->
    <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title">
                  <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Change Secret Password</a>
                </h4>
              </div>
              <div id="collapse2" class="panel-collapse collapse">
                <div class="panel-body">  <form align="center" method="post" action='CheckSecretPassword.php'>
    <div class="panel panel-info">
    <div class="panel-heading">Change Secret Password</div>
    <br>
    <div class="input-group">
        <span class="input-group-addon" id="basic-addon1"><img src="../../Images/Letter.png" alt="HTML5 Icon" width="15" height="15"/></span>
            <input type="password" class="form-control" width="35" height="35" name="currentSecretPassword" placeholder="Current SecretPassword" aria-describedby="basic-addon1">
        <span class="input-group-addon" id="basic-addon1"><img src="../../Images/Letter.png" alt="HTML5 Icon" width="15" height="15"/></span>
            <input type="password" class="form-control" width="35" height="35" name="newSecretPassword"placeholder="New SecretPassword" aria-describedby="basic-addon1">
        <span class="input-group-addon" id="basic-addon1"><img src="../../Images/Password.png" alt="HTML5 Icon" width="15" height="15"/></span>
        <input type="text" class="form-control" width="35" height="35" name="username" placeholder="Username" aria-describedby="basic-addon1">
    </div>
    <br>
    <button class="btn btn-info" type="sumbit">Change KeyWord</button>
    <button class="btn btn-info" type="reset">Clear Fields</button>
    <br>
    <br>
  </form></div>
              </div>
            </div>
<!--Change Username -->
    <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title">
                  <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">Change Username</a>
                </h4>
              </div>
              <div id="collapse4" class="panel-collapse collapse">
                <div class="panel-body">  <form align="center" method="post" action='CheckUsername.php'>
    <div class="panel panel-danger">
    <div class="panel-heading">Change Username</div>
    <br>
    <div class="input-group">
        <span class="input-group-addon" id="basic-addon1"><img src="../../Images/Letter.png" alt="HTML5 Icon" width="15" height="15"/></span>
            <input type="password" class="form-control" width="35" height="35" name="SPassword" placeholder="Current Secret Password" aria-describedby="basic-addon1">
        <span class="input-group-addon" id="basic-addon1"><img src="../../Images/Letter.png" alt="HTML5 Icon" width="15" height="15"/></span>
            <input type="text" class="form-control" width="35" height="35" name="username"placeholder="Username" aria-describedby="basic-addon1">
        <span class="input-group-addon" id="basic-addon1"><img src="../../Images/Password.png" alt="HTML5 Icon" width="15" height="15"/></span>
        <input type="text" class="form-control" width="35" height="35" name="newusername" placeholder="New Username" aria-describedby="basic-addon1">
    </div>
    <br>
    <button class="btn btn-danger" type="sumbit">Change KeyWord</button>
    <button class="btn btn-danger" type="reset">Clear Fields</button>
    <br>
    <br>
  </form></div>
              </div>
            </div>
  </div>
</div>
 <!-- Panel -->
      <!-- Example row of columns -->
      <div class="row">
        <div class="col-lg-4">
          <h2>Safari bug warning!</h2>
          <p class="text-danger">As of v9.1.2, Safari exhibits a bug in which resizing your browser horizontally causes rendering errors in the justified nav that are cleared upon refreshing.</p>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
        </div>
        <div class="col-lg-4">
          <h2>Heading</h2>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
       </div>
        <div class="col-lg-4">
          <h2>Heading</h2>
          <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa.</p>
          <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
        </div>
      </div>
      <!-- Site footer -->
      <footer class="footer">
        <p>&copy; 2016 Company, Inc.</p>
      </footer>
    </div> <!-- /container -->
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../Layout/js/assets/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>