<?php
include '../../../Conn/Conn.php';
include '../../../Conn/Session_ChangeInformation.php';
$currentSecretPassword  = $_POST['currentSecretPassword'];
$newSecretPassword = $_POST['newSecretPassword'];
$username = $_POST['username'];

if($username=="Admin")
{
    //Check, if fields are empty
    if (empty($currentSecretPassword) || empty($newSecretPassword) || empty($username)) {
        echo "<script>alert(\"Please, You should fill all the fields\")</script>";
        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"ChangeInformation.php\";
        }redireciona();
        </script>";
    }
    //Encryption Current Password and New Password 
    $currentSecretPasswordencryption  = sha1($currentSecretPassword);
    $newSecretPasswordencryption   = sha1($newSecretPassword);

    //Check if password exist and user
    $sql = "Select * From SecretPassword s,Login l where s.SecretPassword = '" . $currentSecretPasswordencryption . "' and l.Username = '" . $username . "' ";

    $result = mysqli_query($conn, $sql);
    $n_rows = mysqli_num_rows($result);
        if ($n_rows > 0) {
            $sql_updatepass = "UPDATE SecretPassword SET SecretPassword = '" . $newSecretPasswordencryption . "' WHERE SecretPassword = '" . $currentSecretPasswordencryption . "'";
            if (mysqli_query($conn, $sql_updatepass)) {
                echo "<script>alert(\" SecretPassword has been updated successfully\")</script>";
                echo "<script language=\"JavaScript\">function redireciona() {window.location=\"ChangeInformation.php\";
                }redireciona();
                </script>"; }else {
                echo "<script>alert(\" Error - Try again\")</script>";
                echo "<script language=\"JavaScript\">function redireciona() {window.location=\"ChangeInformation.php\";
                    }redireciona();
                    </script>";}
        }else{
            echo "<script>alert(\"KeyWord OR Password are Wrong\")</script>";
            echo "<script language=\"JavaScript\">function redireciona() {window.location=\"ChangeInformation.php\";
            }redireciona();
            </script>";}
}
else
{
    echo "<script>alert(\"You don't have permission to change Secret Password. Please, you must to contact the administator.\")</script>";
    echo "<script language=\"JavaScript\">function redireciona() {window.location=\"ChangeInformation.php\";
    }redireciona();
    </script>";
}
?> 