<?php
include '../../../Conn/Conn.php';
include '../../../Conn/Session_ChangeInformation.php';
$currentpassword = $_POST['currentPassword'];
$newpassword     = $_POST['newpassword'];
$username         = $_POST['Username'];


//Check, if fields are empty
if (empty($currentpassword) || empty($newpassword) || empty($username)) {
    echo "<script>alert(\"Please, You should fill all the fields\")</script>";
    echo "<script language=\"JavaScript\">function redireciona() {window.location=\"ChangeInformation.php\";
    }redireciona();
    </script>";
}
else
{
    $CURRENTpasswordencryption = sha1($currentpassword);
    $NEWpasswordencryption     = sha1($newpassword);


    $sql = "Select Username, Password From Login where Password = '" . $CURRENTpasswordencryption . "' and Username = '" . $username . "'";

    $result = mysqli_query($conn, $sql);
    $n_rows = mysqli_num_rows($result);
    if ($n_rows > 0) {
        $sql_updatepass = "UPDATE Login SET Password = '" . $NEWpasswordencryption . "' WHERE Password = '" . $CURRENTpasswordencryption . "' AND Username = '" . $username . "'";
        if (mysqli_query($conn, $sql_updatepass)) {
            echo "<script>alert(\" Password has been updated successfully\")</script>";
            echo "<script language=\"JavaScript\">function redireciona() {window.location=\"ChangeInformation.php\";
            }redireciona();
            </script>";
        } else {
            echo "<script>alert(\" Error - Try again\")</script>";
            echo "<script language=\"JavaScript\">function redireciona() {window.location=\"ChangeInformation.php\";
                }redireciona();
                </script>";
            
        }
    } else {
        echo "<script>alert(\"KeyWord OR Password are Wrong\")</script>";
        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"ChangeInformation.php\";
            }redireciona();
            </script>";
    }
}

?> 