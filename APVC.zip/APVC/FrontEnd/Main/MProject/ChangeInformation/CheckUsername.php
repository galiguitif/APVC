<?php
include '../../../Conn/Conn.php';
include '../../../Conn/Session_ChangeInformation.php';
$SPassword  = $_POST['SPassword'];
$Username = $_POST['username'];
$NewUsername = $_POST['newusername'];

$SPasswordencryption  = sha1($SPassword);

//Check, if fields are empty
if (empty($SPassword) || empty($Username) || empty($NewUsername)) {
    echo "<script>alert(\"Please, You should fill all the fields\")</script>";
    echo "<script language=\"JavaScript\">function redireciona() {window.location=\"ChangeInformation.php\";
    }redireciona();
    </script>";
}
else
{
    $sql_checkspassword = "Select SecretPassword From SecretPassword where SecretPassword = '" . $SPasswordencryption . "'";

    $result_checkspassword = mysqli_query($conn, $sql_checkspassword);
    $n_rows_checkspassword = mysqli_num_rows($result_checkspassword);
    if ($n_rows_checkspassword > 0) {

            if($Username=="Admin")
            {
                    echo "<script>alert(\"The admin cannot change the username.\")</script>";
                    echo "<script language=\"JavaScript\">function redireciona() {window.location=\"ChangeInformation.php\";
                    }redireciona();
                    </script>";
            }
            else
            {
                    $sql_checkuser = "Select Username From Login where Username = '" . $NewUsername . "'";

                    $result_checkuser = mysqli_query($conn, $sql_checkuser);
                    $n_rows_checkuser = mysqli_num_rows($result_checkuser);
                    if ($n_rows_checkuser > 0) 
                    {
                    echo "<script>alert(\"This username already exist, please introduce another username please.\")</script>";
                    echo "<script language=\"JavaScript\">function redireciona() {window.location=\"ChangeInformation.php\";
                    }redireciona();
                    </script>";
                    }
                    else
                    {
                        $sql_updatepass = "UPDATE Login SET Username = '" . $NewUsername . "' WHERE Username = '" . $Username . "'";
                        if (mysqli_query($conn, $sql_updatepass)) {
                            
                            echo "<script>alert(\"Username has been updated successfully\")</script>";
                            echo "<script language=\"JavaScript\">function redireciona() {window.location=\"ChangeInformation.php\";
                            }redireciona();
                            </script>";
                        } else {
                            echo "<script>alert(\" Error - Try again\")</script>";
                            echo "<script language=\"JavaScript\">function redireciona() {window.location=\"ChangeInformation.php\";
                                }redireciona();
                                </script>";
                            
                        }
                    }
                 }
        } 
        else
        {
            echo "<script>alert(\"The Secret Password is wrong.\")</script>";
            echo "<script language=\"JavaScript\">function redireciona() {window.location=\"ChangeInformation.php\";
            }redireciona();
            </script>";   
        }  
}


?> 