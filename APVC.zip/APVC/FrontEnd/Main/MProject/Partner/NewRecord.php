<?php
include '../../../Conn/Conn.php';

// Getting Values
$name = $_POST['Name'];
$surname = $_POST['Surname'];
$city = $_POST['City'];
$age = $_POST['Age'];
$phone = $_POST['Phone'];
$email = $_POST['Email'];
$gender = $_POST['Gender'];
$payment=$_POST['Payment'];
$calendar=$_POST['Calendar'];

//check Empty fields
if(empty($name)|| empty($surname)|| empty($surname)|| empty($city)|| empty($age)|| empty($phone)|| empty($email)|| empty($gender)|| empty($payment)|| empty($calendar))
{
        echo "<script>alert(\" Some of those fieds are empty. Please fill them.\")</script>";
        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"Partner.php\";
        }redireciona();
        </script>";
}
else
{
        //Check if the new partner already exist
        $sql_checkuser = "Select Name, Email,Phone From Partner where Name = '" . $name . "' AND Email = '" . $email . "' AND Phone = '" . $phone . "'";

        $result_checkuser = mysqli_query($conn, $sql_checkuser);
        $n_rows_checkuser = mysqli_num_rows($result_checkuser);
        if ($n_rows_checkuser > 0) 
        {
        echo "<script>alert(\"This partner already exist, please introduce check our list from Partners.\")</script>";
        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"ChangeInformation.php\";
        }redireciona();
        </script>";
        }
        else
        {
         //Check if email is valid
         if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            //Insert New Partner
            $newpartner = "INSERT INTO partner (Name,Surname,City,Age,Phone,Email,Gender,Payment,Calendar)
            VALUES ('".$name."','".$surname."','" .$city."','" .$age."','" .$phone."','" .$email."','" .$gender."','" .$payment."','" .$calendar."')";
                if ($conn->query($newpartner) === TRUE) {
                    echo "<script>alert(\"New Partner created successfully\")</script>";
                    echo "<script language=\"JavaScript\">function redireciona() {window.location=\"partner.php\";
                    }redireciona();
                    </script>"; 
                }
                else
                {
                    echo "<script>alert(\"ERROR to to create the new partner.\")</script>";
                    echo "<script language=\"JavaScript\">function redireciona() {window.location=\"partner.php\";
                    }redireciona();
                    </script>"; 
                }
         }else
         {
            echo "<script>alert(\"It is not  valid email address\")</script>";
            echo "<script language=\"JavaScript\">function redireciona() {window.location=\"partner.php\";
            }redireciona();
            </script>";  
         }
        }
}
?> 



