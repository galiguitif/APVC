<?php
include '../../../Conn/Conn.php';

// Getting Values
$name = $_POST['Name'];
$surname = $_POST['Surname'];
$phone = $_POST['Phone'];
$email = $_POST['Email'];
$changePartner = $_POST['ChangePartner'];
$newfield = $_POST['NewField'];
if(empty($name) || empty($surname) || empty($phone) ||empty($email) ||empty($changePartner)||empty($newfield))
{
        echo "<script>alert(\" Some of those fieds are empty. Please fill them.\")</script>";
        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"Partner.php\";
        }redireciona();
        </script>";
}
else
{
        if ($changePartner=="Payment" && (!($newfield=="Paid" || $newfield=="NotPaid" )))
        {
                echo "<script>alert(\"The field Payment JUST accept Paid or Not Paid. Please Try again.\")</script>";
                echo "<script language=\"JavaScript\">function redireciona() {window.location=\"partner.php\";
                }redireciona();
                </script>"; 
        }
        else
        {
               if ($changePartner=="Payment")
               {
                        $sqlDate = "SELECT CURDATE()";
                        $result = $conn->query($sqlDate);
                        if ($result->num_rows > 0) {
                        // output data of each row
                         while($row = $result->fetch_assoc()) {
                         
                          $CurrentDate=$row['CURDATE()'];
                         }
                        }
                        $sqlUpdateDate = "UPDATE Partner SET Calendar='" .$CurrentDate."' WHERE Name='" .$name."' AND Surname='" .$surname."' AND Phone='" .$phone."' AND Email='" .$email."'";
                        $result = $conn->query($sqlUpdateDate);
                         //Select Partner
                        $selectpartner = "SELECT * FROM Partner WHERE Name='" .$name."' AND Surname='" .$surname."' AND Phone='" .$phone."' AND Email='" .$email."'";
                        $result_checkpartner = mysqli_query($conn, $selectpartner);
                        $n_rows_checkpartner = mysqli_num_rows($result_checkpartner);
                        if ($n_rows_checkpartner > 0) 
                        {      
                                $sql_updatefield = "UPDATE Partner SET $changePartner = '" . $newfield . "' WHERE name = '" . $name . "' AND Surname = '" . $surname . "' AND Phone = '" . $phone . "' AND Email = '" . $email . "'";
                                if ($conn->query($sql_updatefield) === TRUE) {
                                        echo "<script>alert(\"The Partner has been Updated.\")</script>";
                                        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"partner.php\";
                                        }redireciona();
                                        </script>"; 
                                } else 
                                {
                                        echo "<script>alert(\"The Partner not has been Updated\")</script>";
                                        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"partner.php\";
                                        }redireciona();
                                        </script>"; 
                                }

                        }
                        else
                        {
                        echo "<script>alert(\"The Partner does not exist\")</script>";
                        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"partner.php\";
                        }redireciona();
                        </script>"; 
                        }
                       
               } 
               else
               {
                        //Select Partner
                        $selectpartner = "SELECT * FROM Partner WHERE Name='" .$name."' AND Surname='" .$surname."' AND Phone='" .$phone."' AND Email='" .$email."'";
                        $result_checkpartner = mysqli_query($conn, $selectpartner);
                        $n_rows_checkpartner = mysqli_num_rows($result_checkpartner);
                        if ($n_rows_checkpartner > 0) 
                        {      
                                $sql_updatefield = "UPDATE Partner SET $changePartner = '" . $newfield . "' WHERE name = '" . $name . "' AND Surname = '" . $surname . "' AND Phone = '" . $phone . "' AND Email = '" . $email . "'";
                                if ($conn->query($sql_updatefield) === TRUE) {
                                        echo "<script>alert(\"The Partner has been Updated.\")</script>";
                                        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"partner.php\";
                                        }redireciona();
                                        </script>"; 
                                } else 
                                {
                                        echo "<script>alert(\"The Partner not has been Updated\")</script>";
                                        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"partner.php\";
                                        }redireciona();
                                        </script>"; 
                                }

                        }
                        else
                        {
                        echo "<script>alert(\"The Partner does not exist\")</script>";
                        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"partner.php\";
                        }redireciona();
                        </script>"; 
                        }
               }      
        }
}
?> 



