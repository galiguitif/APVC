<?PHP include '../../../Conn/Session_MProject.php'; ?>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="initial-scale=1.0, maximum-scale=2.0">
    <title>APVC</title>
    <!-- Bootstrap core CSS -->
    <link href="../../Layout/css/dist/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../../Layout/css/assets/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="justified-nav.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../Layout/js/assets/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

     <!-- Panel -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!--Panel -->


	<link rel="stylesheet" type="text/css" href="layout/media/css/jquery.dataTables.css">
	<link rel="stylesheet" type="text/css" href="layout/css/buttons.dataTables.css">
	<link rel="stylesheet" type="text/css" href="layout/resources/syntax/shCore.css">

	<style type="text/css" class="init">
	
	</style>
	<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.12.4.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/media/js/jquery.dataTables.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/js/dataTables.buttons.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/js/buttons.flash.js">
	</script>
	<script type="text/javascript" language="javascript" src="//cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/pdfmake.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/vfs_fonts.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/js/buttons.html5.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/js/buttons.print.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/examples/resources/syntax/shCore.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/examples/resources/demo.js">
	</script>
	<script type="text/javascript" language="javascript" class="init">
	
$(document).ready(function() {
	$('#example').DataTable( {
		dom: 'Bfrtip',
		buttons: [
			'copy', 'csv', 'excel', 'pdf', 'print'
		]
	} );
} );
	</script>
</head>
<body class="dt-example">
    <div class="container">
      <!-- The justified navigation menu is meant for single line per list item.
           Multiple lines will require custom code not provided by Bootstrap. -->
      <div class="masthead">
	        <h3 class="text-muted">APVC</h3>
        <nav>
          <ul class="nav nav-justified">
            <li><a href="../index.php">Home</a></li>
            <li><a href="../InfoAdmin/InfoAdmin.php">InfoAdmin</a></li>
            <li><a href="../PaymentControl/PaymentControl.php">PaymentControl</a></li>
            <li class="active"><a href="Partner.php">Partner</a></li>
             <li><a href="../Framework/Framework.php">Framework</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
        </nav>
      </div>
<br>
    </div>
	<div class="container">
		<section>
      <h2>List -  Partners</h2>
			<table id="example" class="display nowrap" cellspacing="0" width="100%">
			    <?PHP
include '../../../Conn/conn.php';
$sql    = "Select Name,Surname,Phone,Email,City,Gender,Age,Calendar,Payment from Partner where 1=1";
$result = $conn->query($sql);
print '<thead>';
print '<tr>';
print '<th>Name</th>';
print '<th>Surname</th>';
print '<th>Phone</th>';
print '<th>Email</th>';
print '<th>City</th>';
print '<th>Gender</th>';
print '<th>Age</th>';
print '<th>Calendar</th>';
print '<th>Payment</th>';
print '</tr>';
print '</thead>';
print '<tfoot>';
print '<tr>';
print '<th>Name</th>';
print '<th>Surname</th>';
print '<th>Phone</th>';
print '<th>Email</th>';
print '<th>City</th>';
print '<th>Gender</th>';
print '<th>Age</th>';
print '<th>Calendar</th>';
print '<th>Payment</th>';
print '</tr>';
print '</tfoot>';
print '<tbody>';
if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {
        print '<tr>';
        foreach ($row as $item) {
            print '<td>' . ($item !== null ? htmlentities($item, ENT_QUOTES) : '&nbsp') . '</td>';
          
        }
        print '</tr>';
    }
}
print '</tbody>';
?>	
			</table>

				
	</section>
<br>
<br>

<div align="center"><img src="../../Images/Preloader_3.gif" alt="HTML5 Icon" width="75" height="75"/></div>
<div class="container">
<!--New Partner-->
<div class="container">
  <h2>Configuration about Partners</h2>
  <div class="panel-group" id="accordion">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">Create New Partner</a>
        </h4>
      </div>
      <div id="collapse1" class="panel-collapse collapse in">
        <div class="panel-body">
          <!--FORM-->
          <form action="NewRecord.php" method="POST">
            <!--PANEL group-->
            <div class="panel-group">
              <div class="panel panel-default">
                <div class="panel-body">
                  <!-- Name input -->
                  <div class="form-group has-success">
                    <label class="control-label" for="inputSucess1">Name</label>
                    <input type="text" name="Name" placeholder="Name" class="form-control" id="inputSucess1">
                  </div>
                  <!-- Surname input -->
                  <div class="form-group has-warning">
                    <label class="control-label" for="inputWarning1">Surname</label>
                    <input type="text"  name="Surname" placeholder="Surname" class="form-control" id="inputWarning1">
                  </div>
                  <!-- Phone input -->
                  <div class="form-group has-error">
                    <label class="control-label" for="inputError1">Phone</label>
                    <input type="text" name="Phone" placeholder="Phone" class="form-control" id="inputError1">
                  </div>
                  <!-- Email input -->
                  <div class="form-group has-success">
                    <label class="control-label" for="inputSucess1">Email</label>
                    <input type="text" name="Email" placeholder="Email" class="form-control" id="inputSucess1">
                  </div>
                  <!-- City input -->
                  <div class="form-group has-warning">
                    <label class="control-label" for="inputWarning1">City</label>
                    <input type="text"  name="City" placeholder="City" class="form-control" id="inputWarning1">
                  </div>
                  <!-- Gender input -->
                  <div class="form-group has-error">
                    <label class="control-label" for="inputError1">Gender</label>
                    <select name="Gender">
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                  </div>
                  <!-- Age input -->
                  <div class="form-group has-success">
                    <label class="control-label" for="inputSucess1">Age</label>
                    <input type="text" name="Age" placeholder="Age" class="form-control" id="inputSucess1">
                  </div>
                  <!-- Calendar input -->
                  <div class="form-group has-warning">
                      <label class="control-label" for="inputWarning1">Calendar</label>
                      <input type="date"  name="Calendar" placeholder="Calendar" class="form-control" id="inputWarning1">
                  </div>
                  <!-- Payment input -->
                  <div class="form-group has-error">
                      <label class="control-label" for="inputError1">Payment</label>
                      <select name="Payment">
              <option value="Paid">Paid</option>
              <option value="Not Paid">Not Paid</option>
            </select>
        </div>
        <!-- Buttons -->
        <div align="center"><button type="submit" class="btn btn-primary">New Record</button> <button type="reset" class="btn btn-primary">Clear Fields</button>  </div>
     </div>
    </div>  
</form>
</div>
</div>
</div>
<!--Delete Partner-->
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Remove Partner</a>
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
        <div class="panel-body">
          <!--FORM-->
          <form action="RemovePartner.php" method="POST">
            <!--PANEL group-->
            <div class="panel-group">
              <div class="panel panel-default">
                <div class="panel-body">
                  <!-- Name input -->
                  <div class="form-group has-success">
                    <label class="control-label" for="inputSucess1">Name</label>
                    <input type="text" name="Name" placeholder="Name" class="form-control" id="inputSucess1">
                  </div>
                  <!-- Surname input -->
                  <div class="form-group has-warning">
                    <label class="control-label" for="inputWarning1">Surname</label>
                    <input type="text"  name="Surname" placeholder="Surname" class="form-control" id="inputWarning1">
                  </div>
                  <!-- Phone input -->
                  <div class="form-group has-error">
                    <label class="control-label" for="inputError1">Phone</label>
                    <input type="text" name="Phone" placeholder="Phone" class="form-control" id="inputError1">
                  </div>
                  <!-- Email input -->
                  <div class="form-group has-success">
                    <label class="control-label" for="inputSucess1">Email</label>
                    <input type="text" name="Email" placeholder="Email" class="form-control" id="inputSucess1">
                  </div>
                   <!-- Buttons -->
                  <div align="center"><button type="submit" class="btn btn-primary">Remove Partner</button> <button type="reset" class="btn btn-primary">Clear Fields</button>  </div>
          </form>
      </div>
  </div>
</div>
</div>
</div>
<!--Change Partner-->
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">Change Data Partner</a>
        </h4>
      </div>
      <div id="collapse3" class="panel-collapse collapse">
        <div class="panel-body">
           <!--FORM-->
          <form action="UpdatePartner.php" method="POST">
                  <!-- Name input -->
                  <div class="form-group has-success">
                    <label class="control-label" for="inputSucess1">Name</label>
                    <input type="text" name="Name" placeholder="Name" class="form-control" id="inputSucess1">
                  </div>
                  <!-- Surname input -->
                  <div class="form-group has-warning">
                    <label class="control-label" for="inputWarning1">Surname</label>
                    <input type="text"  name="Surname" placeholder="Surname" class="form-control" id="inputWarning1">
                  </div>
                  <!-- Phone input -->
                  <div class="form-group has-error">
                    <label class="control-label" for="inputError1">Phone</label>
                    <input type="text" name="Phone" placeholder="Phone" class="form-control" id="inputError1">
                  </div>
                  <!-- Email input -->
                  <div class="form-group has-success">
                    <label class="control-label" for="inputSucess1">Email</label>
                    <input type="text" name="Email" placeholder="Email" class="form-control" id="inputSucess1">
                  </div>
                   <!-- ChangePartner input -->
                  <div class="form-group has-error">
                      <label class="control-label" for="inputError1">What do you want update?</label>
                      <select name="ChangePartner">
                        <option value="Name">Name</option>
                        <option value="Surname">Surname</option>
                        <option value="Phone">Phone</option>
                        <option value="Email">Email</option>
                        <option value="City">City</option>
                        <option value="Age">Age</option>
                        <option value="Payment">Payment</option>
                       </select>
                 </div>
                   <!-- New Field input -->
                  <div class="form-group has-warning">
                      <label class="control-label" for="inputWarning1">New Field to update</label>
                      <input type="text"  name="NewField" placeholder="New Field to update" class="form-control" id="inputWarning1">
                  </div>
                <!-- Buttons -->
                <div align="center"><button type="submit" class="btn btn-primary">Change Data</button> <button type="reset" class="btn btn-primary">Clear Fields</button>  </div>
        </div>
      </div>
      </form>
    </div>
  </div> 
</div>

      <!-- Example row of columns -->
      <div class="row">
        <div class="col-lg-4">
          <h2>Safari bug warning!</h2>
          <p class="text-danger">As of v9.1.2, Safari exhibits a bug in which resizing your browser horizontally causes rendering errors in the justified nav that are cleared upon refreshing.</p>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
        </div>
        <div class="col-lg-4">
          <h2>Heading</h2>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
       </div>
        <div class="col-lg-4">
          <h2>Heading</h2>
          <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa.</p>
          <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
        </div>
      </div>
      <!-- Site footer -->
      <footer class="footer">
        <p>&copy; 2016 Company, Inc.</p>
      </footer>
    </div> <!-- /container -->
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../Layout/js/assets/ie10-viewport-bug-workaround.js"></script>
</body>
</html>