<?php
include '../../../Conn/Conn.php';

// Getting Values
$name = $_POST['Name'];
$surname = $_POST['Surname'];
$phone = $_POST['Phone'];
$email = $_POST['Email'];

if(empty($name) || empty($surname) || empty($phone) ||empty($email))
{
        echo "<script>alert(\" Some of those fieds are empty. Please fill them.\")</script>";
        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"Partner.php\";
        }redireciona();
        </script>";
}
else
{


    //Insert New record
    $selectpartner = "SELECT * FROM Partner WHERE Name='" .$name."' AND Surname='" .$surname."' AND Phone='" .$phone."' AND Email='" .$email."'";
        $result_checkpartner = mysqli_query($conn, $selectpartner);
        $n_rows_checkpartner = mysqli_num_rows($result_checkpartner);
        if ($n_rows_checkpartner > 0) 
        {       
                $removerecord = "DELETE FROM Partner WHERE Name='" .$name."' AND Surname='" .$surname."' AND Phone='" .$phone."' AND Email='" .$email."'";

                if ($conn->query($removerecord) === TRUE) {
                        echo "<script>alert(\"The Partner has been removed.\")</script>";
                        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"partner.php\";
                        }redireciona();
                        </script>"; 
                } else 
                {
                        echo "<script>alert(\"The Partner not has been removed\")</script>";
                        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"partner.php\";
                        }redireciona();
                        </script>"; 
                }

        }
        else
        {
            echo "<script>alert(\"The Partner does not exist\")</script>";
            echo "<script language=\"JavaScript\">function redireciona() {window.location=\"partner.php\";
            }redireciona();
            </script>"; 
        }
}
?> 



