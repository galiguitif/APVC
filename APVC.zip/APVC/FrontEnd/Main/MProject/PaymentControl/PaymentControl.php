<?PHP include '../../../Conn/Session_MProject.php'; ?>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="initial-scale=1.0, maximum-scale=2.0">
		 <title>APVC</title>
    <!-- Bootstrap core CSS -->
    <link href="../../Layout/css/dist/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../../Layout/css/assets/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="justified-nav.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../Layout/js/assets/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

     <!-- Panel -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!--Panel -->


	<link rel="stylesheet" type="text/css" href="layout/media/css/jquery.dataTables.css">
	<link rel="stylesheet" type="text/css" href="layout/css/buttons.dataTables.css">
	<link rel="stylesheet" type="text/css" href="layout/resources/syntax/shCore.css">

	<style type="text/css" class="init">
	
	</style>
	<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.12.4.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/media/js/jquery.dataTables.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/js/dataTables.buttons.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/js/buttons.flash.js">
	</script>
	<script type="text/javascript" language="javascript" src="//cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/pdfmake.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/vfs_fonts.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/js/buttons.html5.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/js/buttons.print.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/examples/resources/syntax/shCore.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/examples/resources/demo.js">
	</script>
	<script type="text/javascript" language="javascript" class="init">
	
$(document).ready(function() {
	$('#example').DataTable( {
		dom: 'Bfrtip',
		buttons: [
			'copy', 'csv', 'excel', 'pdf', 'print'
		]
	} );
} );
	</script>
</head>
<body class="dt-example">

    <div class="container">
      <!-- The justified navigation menu is meant for single line per list item.
           Multiple lines will require custom code not provided by Bootstrap. -->
      <div class="masthead">
	        <h3 class="text-muted">APVC</h3>
        <nav>
          <ul class="nav nav-justified">
            <li><a href="../index.php">Home</a></li>
            <li><a href="../InfoAdmin/InfoAdmin.php">InfoAdmin</a></li>
            <li class="active"><a href="PaymentControl.php">PaymentControl</a></li>
            <li><a href="../Partner/Partner.php">Partner</a></li>
            <li><a href="../Framework/Framework.php">Framework</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
        </nav>
      </div>
<br>
    </div>
	<div class="container">
		<section>
			<table id="example" class="display nowrap" cellspacing="0" width="100%">
			    <?PHP
include '../../../Conn/conn.php';
$sql    = "Select Name,Surname,Email,Phone,Payment,Calendar from Partner where Payment='Not Paid'";
$result = $conn->query($sql);
print '<thead>';
print '<tr>';
print '<th>Name</th>';
print '<th>Surname</th>';
print '<th>Email</th>';
print '<th>Phone</th>';
print '<th>Payment</th>';
print '<th>Calendar</th>';
print '</tr>';
print '</thead>';
print '<tfoot>';
print '<tr>';
print '<th>Name</th>';
print '<th>Surname</th>';
print '<th>Email</th>';
print '<th>Phone</th>';
print '<th>Payment</th>';
print '<th>Calendar</th>';
print '</tr>';
print '</tfoot>';
print '<tbody>';
if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {
        print '<tr>';
        foreach ($row as $item) {
            print '<td>' . ($item !== null ? htmlentities($item, ENT_QUOTES) : '&nbsp') . '</td>';
          
        }
        print '</tr>';
    }
    
}
print '</tbody>';
?>	
			</table>

				
	</section>
<br>
<br>
      <!-- Example row of columns -->
      <div class="row">
        <div class="col-lg-4">
          <h2>Safari bug warning!</h2>
          <p class="text-danger">As of v9.1.2, Safari exhibits a bug in which resizing your browser horizontally causes rendering errors in the justified nav that are cleared upon refreshing.</p>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
        </div>
        <div class="col-lg-4">
          <h2>Heading</h2>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
       </div>
        <div class="col-lg-4">
          <h2>Heading</h2>
          <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa.</p>
          <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
        </div>
      </div>
      <!-- Site footer -->
      <footer class="footer">
        <p>&copy; 2016 Company, Inc.</p>
      </footer>
    </div> <!-- /container -->
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../Layout/js/assets/ie10-viewport-bug-workaround.js"></script>
</body>
</html>