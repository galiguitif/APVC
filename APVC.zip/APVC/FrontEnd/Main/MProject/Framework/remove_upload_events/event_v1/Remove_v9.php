
<?php
// Target
$target_dir = "../../upload_events/event_v1/File_v9/";

$files_in_directory = scandir('../../upload_events/event_v1/File_v9/');
$items_count = count($files_in_directory);
if ($items_count <= 2)
{
       echo "<script>alert(\"The Directory is empy.\")</script>";
        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../../Framework.php\";
        }redireciona();
        </script>";
}
else {
    //Get a list of all of the file names in the folder.
$files = glob($target_dir . '/*');
//Loop through the file list.
foreach($files as $file){
    //Make sure that this is a file and not a directory.
    if(is_file($file)){
        //Use the unlink function to delete the file.
        unlink($file);
        echo "<script>alert(\"The file was removed.\")</script>";
        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../../Framework.php\";
        }redireciona();
        </script>";
    }
    else
    {
        echo "<script>alert(\"Sorry, The file wasn't removed.\")</script>";
        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../../Framework.php\";
        }redireciona();
        </script>";
    }
}
}


?>




