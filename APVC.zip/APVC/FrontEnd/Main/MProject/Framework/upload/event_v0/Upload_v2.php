
<?php
// Tagert Upload
$target_dir = "../../upload_events/event_v0/File_v2/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

if ($_FILES["fileToUpload"]["error"] > 0)
  {
    echo "<script>alert(\"File Upload is empty.\")</script>";
    echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../../Framework.php\";
    }redireciona();
    </script>";
  }
  else
{

        //Get a list of all of the file names in the folder.
        $files = glob($target_dir . '/*');
        
        //Loop through the file list.
        foreach($files as $file){
            //Make sure that this is a file and not a directory.
            if(is_file($file)){
                //Use the unlink function to delete the file.
                unlink($file);
            }
        }


        // Check file size
        if ($_FILES["fileToUpload"]["size"] > 500000) {
            echo "<script>alert(\"Sorry, your file is too large.\")</script>";
            echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../../Framework.php\";
            }redireciona();
            </script>";
            $uploadOk = 0;
        }
        // Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
            echo "<script>alert(\"Sorry, only JPG, JPEG, PNG & GIF files are allowed.\")</script>";
            echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../../Framework.php\";
            }redireciona();
            </script>";
            $uploadOk = 0;
        }
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "<script>alert(\"Sorry, your file was not uploaded.\")</script>";
            echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../../Framework.php\";
            }redireciona();
            </script>";
        // if everything is ok, try to upload file
        } else {
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                echo "<script>alert(\"The file has been uploaded \")</script>";
                echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../../Framework.php\";
                }redireciona();
                </script>";
            } else {
                echo "<script>alert(\"Sorry, there was an error uploading your file.\")</script>";
                echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../../Framework.php\";
                }redireciona();
                </script>";
            }
        }
}


?>




