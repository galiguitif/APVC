<?PHP include '../../../Conn/Session_MProject.php'; ?>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="initial-scale=1.0, maximum-scale=2.0">
	
    <!-- Bootstrap core CSS -->
    <link href="../../Layout/css/dist/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../../Layout/css/assets/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="justified-nav.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../Layout/js/assets/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

     <!-- Panel -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!--Panel -->

<style>
td,tr {
    font-size: 90%;
}
</style>

</head>
<body class="dt-example">
    <div class="container">
      <!-- The justified navigation menu is meant for single line per list item.
           Multiple lines will require custom code not provided by Bootstrap. -->
      <div class="masthead">
	        <h3 class="text-muted">Project name</h3>
        <nav>
          <ul class="nav nav-justified">
            <li><a href="../index.php">Home</a></li>
            <li><a href="../InfoAdmin/InfoAdmin.php">InfoAdmin</a></li>
            <li><a href="../PaymentControl/PaymentControl.php">PaymentControl</a></li>
            <li><a href="../Partner/Partner.php">Partner</a></li>
            <li class="active"><a href="Framework.php">Framework</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
        </nav>
      </div>
<br>
</div>
<!--Event 0 -->
<div class="container">
  <h2>Event[0]: Upload Photos <img src="../../Images/FileUpload.jpg" height="55" width="55"></h2>
  <table align="center" font size="6" border="1">
            <tr>
              <th style="text-align:center">File</th>
              <th style="text-align:center">Choose File</th> 
              <th style="text-align:center">Upload</th>
              <th style="text-align:center">Remove</th>
              <th style="text-align:center">Status</th>
            </tr>
            <tr>
              <form action="upload/event_v0/Upload_v0.php" method="post" enctype="multipart/form-data">
                <td>File[0]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v0/Remove_v0.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v0/File_v0/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
             </tr> 
             <tr>
              <form action="upload/event_v0/Upload_v1.php" method="post" enctype="multipart/form-data">
                <td>File[1]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v0/Remove_v1.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v0/File_v1/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
             </tr> 
             <tr>
              <form action="upload/event_v0/Upload_v2.php" method="post" enctype="multipart/form-data">
                <td>File[2]: Select image to upload:</td>
                  <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v0/Remove_v2.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v0/File_v2/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v0/Upload_v3.php" method="post" enctype="multipart/form-data">
                <td>File[3]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v0/Remove_v3.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v0/File_v3/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v0/Upload_v4.php" method="post" enctype="multipart/form-data">
                <td>File[4]: Select image to upload:</td>
              <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v0/Remove_v4.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v0/File_v4/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v0/Upload_v5.php" method="post" enctype="multipart/form-data">
                <td>File[5]: Select image to upload:</td>
               <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v0/Remove_v5.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v0/File_v5/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v0/Upload_v6.php" method="post" enctype="multipart/form-data">
                <td>File[6]: Select image to upload:</td>
                      <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v0/Remove_v6.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v0/File_v6/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v0/Upload_v7.php" method="post" enctype="multipart/form-data">
                <td>File[7]: Select image to upload:</td>
                    <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v0/Remove_v7.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v0/File_v7/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v0/Upload_v8.php" method="post" enctype="multipart/form-data">
                <td>File[8]: Select image to upload:</td>
                  <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v0/Remove_v8.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v0/File_v8/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v0/Upload_v9.php" method="post" enctype="multipart/form-data">
                <td>File[9]: Select image to upload:</td>
                   <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v0/Remove_v9.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v0/File_v9/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v0/Upload_v10.php" method="post" enctype="multipart/form-data">
                <td>File[10]: Select image to upload:</td>
                     <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v0/Remove_v10.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v0/File_v10/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v0/Upload_v11.php" method="post" enctype="multipart/form-data">
                <td>File[11]: Select image to upload:</td>
                       <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v0/Remove_v11.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v0/File_v11/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v0/Upload_v12.php" method="post" enctype="multipart/form-data">
                <td>File[12]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v0/Remove_v12.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v0/File_v12/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v0/Upload_v13.php" method="post" enctype="multipart/form-data">
                <td>File[13]: Select image to upload:</td>
                 <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v0/Remove_v13.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v0/File_v13/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v0/Upload_v14.php" method="post" enctype="multipart/form-data">
                <td>File[14]: Select image to upload:</td>
              <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v0/Remove_v14.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v0/File_v14/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                 ?>
             </tr> 
             <tr>
          <table>
</div>
<!--Event 1 -->
<div class="container">
  <h2>Event[1]: Upload Photos <img src="../../Images/FileUpload.jpg" height="55" width="55"></h2>
  <table align="center" font size="6" border="1">
            <tr>
              <th style="text-align:center">File</th>
              <th style="text-align:center">Choose File</th> 
              <th style="text-align:center">Upload</th>
              <th style="text-align:center">Remove</th>
              <th style="text-align:center">Status</th>
            </tr>
            <tr>
              <form action="upload/event_v1/Upload_v0.php" method="post" enctype="multipart/form-data">
                <td>File[0]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v1/Remove_v0.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v1/File_v0/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
             </tr> 
             <tr>
              <form action="upload/event_v1/Upload_v1.php" method="post" enctype="multipart/form-data">
                <td>File[1]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v1/Remove_v1.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v1/File_v1/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
             </tr> 
             <tr>
              <form action="upload/event_v1/Upload_v2.php" method="post" enctype="multipart/form-data">
                <td>File[2]: Select image to upload:</td>
                  <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v1/Remove_v2.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v1/File_v2/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v1/Upload_v3.php" method="post" enctype="multipart/form-data">
                <td>File[3]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v1/Remove_v3.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v1/File_v3/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v1/Upload_v4.php" method="post" enctype="multipart/form-data">
                <td>File[4]: Select image to upload:</td>
              <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v1/Remove_v4.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v1/File_v4/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v1/Upload_v5.php" method="post" enctype="multipart/form-data">
                <td>File[5]: Select image to upload:</td>
               <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v1/Remove_v5.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v1/File_v5/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v1/Upload_v6.php" method="post" enctype="multipart/form-data">
                <td>File[6]: Select image to upload:</td>
                      <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v1/Remove_v6.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v1/File_v6/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v1/Upload_v7.php" method="post" enctype="multipart/form-data">
                <td>File[7]: Select image to upload:</td>
                    <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v1/Remove_v7.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v1/File_v7/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v1/Upload_v8.php" method="post" enctype="multipart/form-data">
                <td>File[8]: Select image to upload:</td>
                  <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v1/Remove_v8.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v1/File_v8/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v1/Upload_v9.php" method="post" enctype="multipart/form-data">
                <td>File[9]: Select image to upload:</td>
                   <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v1/Remove_v9.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v1/File_v9/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v1/Upload_v10.php" method="post" enctype="multipart/form-data">
                <td>File[10]: Select image to upload:</td>
                     <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v1/Remove_v10.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v1/File_v10/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v1/Upload_v11.php" method="post" enctype="multipart/form-data">
                <td>File[11]: Select image to upload:</td>
                       <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v1/Remove_v11.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v1/File_v11/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v1/Upload_v12.php" method="post" enctype="multipart/form-data">
                <td>File[12]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v1/Remove_v12.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v1/File_v12/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v1/Upload_v13.php" method="post" enctype="multipart/form-data">
                <td>File[13]: Select image to upload:</td>
                 <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v1/Remove_v13.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v1/File_v13/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v1/Upload_v14.php" method="post" enctype="multipart/form-data">
                <td>File[14]: Select image to upload:</td>
              <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v1/Remove_v14.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v1/File_v14/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                 ?>
             </tr> 
             <tr>
          <table>
</div>


<!--Event 2 -->
<div class="container">
  <h2>Event[2]: Upload Photos <img src="../../Images/FileUpload.jpg" height="55" width="55"></h2>
  <table align="center" font size="6" border="1">
            <tr>
              <th style="text-align:center">File</th>
              <th style="text-align:center">Choose File</th> 
              <th style="text-align:center">Upload</th>
              <th style="text-align:center">Remove</th>
              <th style="text-align:center">Status</th>
            </tr>
            <tr>
              <form action="upload/event_v2/Upload_v0.php" method="post" enctype="multipart/form-data">
                <td>File[0]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v2/Remove_v0.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v2/File_v0/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
             </tr> 
             <tr>
              <form action="upload/event_v2/Upload_v1.php" method="post" enctype="multipart/form-data">
                <td>File[1]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v2/Remove_v1.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v2/File_v1/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
             </tr> 
             <tr>
              <form action="upload/event_v2/Upload_v2.php" method="post" enctype="multipart/form-data">
                <td>File[2]: Select image to upload:</td>
                  <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v2/Remove_v2.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v2/File_v2/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v2/Upload_v3.php" method="post" enctype="multipart/form-data">
                <td>File[3]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v2/Remove_v3.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v2/File_v3/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v2/Upload_v4.php" method="post" enctype="multipart/form-data">
                <td>File[4]: Select image to upload:</td>
              <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v2/Remove_v4.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v2/File_v4/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v2/Upload_v5.php" method="post" enctype="multipart/form-data">
                <td>File[5]: Select image to upload:</td>
               <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v2/Remove_v5.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v2/File_v5/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v2/Upload_v6.php" method="post" enctype="multipart/form-data">
                <td>File[6]: Select image to upload:</td>
                      <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v2/Remove_v6.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v2/File_v6/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v2/Upload_v7.php" method="post" enctype="multipart/form-data">
                <td>File[7]: Select image to upload:</td>
                    <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v2/Remove_v7.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v2/File_v7/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v2/Upload_v8.php" method="post" enctype="multipart/form-data">
                <td>File[8]: Select image to upload:</td>
                  <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v2/Remove_v8.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v2/File_v8/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v2/Upload_v9.php" method="post" enctype="multipart/form-data">
                <td>File[9]: Select image to upload:</td>
                   <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v2/Remove_v9.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v2/File_v9/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v2/Upload_v10.php" method="post" enctype="multipart/form-data">
                <td>File[10]: Select image to upload:</td>
                     <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v2/Remove_v10.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v2/File_v10/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v2/Upload_v11.php" method="post" enctype="multipart/form-data">
                <td>File[11]: Select image to upload:</td>
                       <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v2/Remove_v11.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v2/File_v11/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v2/Upload_v12.php" method="post" enctype="multipart/form-data">
                <td>File[12]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v2/Remove_v12.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v2/File_v12/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v2/Upload_v13.php" method="post" enctype="multipart/form-data">
                <td>File[13]: Select image to upload:</td>
                 <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v2/Remove_v13.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v2/File_v13/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v2/Upload_v14.php" method="post" enctype="multipart/form-data">
                <td>File[14]: Select image to upload:</td>
              <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v2/Remove_v14.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v2/File_v14/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                 ?>
             </tr> 
          <table>
</div>

<!--Event 3 -->
<div class="container">
  <h2>Event[3]: Upload Photos <img src="../../Images/FileUpload.jpg" height="55" width="55"></h2>
  <table align="center" font size="6" border="1">
            <tr>
              <th style="text-align:center">File</th>
              <th style="text-align:center">Choose File</th> 
              <th style="text-align:center">Upload</th>
              <th style="text-align:center">Remove</th>
              <th style="text-align:center">Status</th>
            </tr>
            <tr>
              <form action="upload/event_v3/Upload_v0.php" method="post" enctype="multipart/form-data">
                <td>File[0]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v3/Remove_v0.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v3/File_v0/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
             </tr> 
             <tr>
              <form action="upload/event_v3/Upload_v1.php" method="post" enctype="multipart/form-data">
                <td>File[1]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v3/Remove_v1.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v3/File_v1/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
             </tr> 
             <tr>
              <form action="upload/event_v3/Upload_v2.php" method="post" enctype="multipart/form-data">
                <td>File[2]: Select image to upload:</td>
                  <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v3/Remove_v2.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v3/File_v2/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v3/Upload_v3.php" method="post" enctype="multipart/form-data">
                <td>File[3]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v3/Remove_v3.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v3/File_v3/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v3/Upload_v4.php" method="post" enctype="multipart/form-data">
                <td>File[4]: Select image to upload:</td>
              <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v3/Remove_v4.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v3/File_v4/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v3/Upload_v5.php" method="post" enctype="multipart/form-data">
                <td>File[5]: Select image to upload:</td>
               <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v3/Remove_v5.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v3/File_v5/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v3/Upload_v6.php" method="post" enctype="multipart/form-data">
                <td>File[6]: Select image to upload:</td>
                      <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v3/Remove_v6.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v3/File_v6/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v3/Upload_v7.php" method="post" enctype="multipart/form-data">
                <td>File[7]: Select image to upload:</td>
                    <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v3/Remove_v7.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v3/File_v7/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v3/Upload_v8.php" method="post" enctype="multipart/form-data">
                <td>File[8]: Select image to upload:</td>
                  <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v3/Remove_v8.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v3/File_v8/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v3/Upload_v9.php" method="post" enctype="multipart/form-data">
                <td>File[9]: Select image to upload:</td>
                   <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v3/Remove_v9.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v3/File_v9/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v3/Upload_v10.php" method="post" enctype="multipart/form-data">
                <td>File[10]: Select image to upload:</td>
                     <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v3/Remove_v10.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v3/File_v10/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v3/Upload_v11.php" method="post" enctype="multipart/form-data">
                <td>File[11]: Select image to upload:</td>
                       <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v3/Remove_v11.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v3/File_v11/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v3/Upload_v12.php" method="post" enctype="multipart/form-data">
                <td>File[12]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v3/Remove_v12.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v3/File_v12/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v3/Upload_v13.php" method="post" enctype="multipart/form-data">
                <td>File[13]: Select image to upload:</td>
                 <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v3/Remove_v13.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v3/File_v13/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="upload/event_v3/Upload_v14.php" method="post" enctype="multipart/form-data">
                <td>File[14]: Select image to upload:</td>
              <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_events/event_v3/Remove_v14.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "upload_events/event_v3/File_v14/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                 ?>
             </tr> 
          <table>
</div>



<!--Cubo 3D -->
<div class="container">
  <h2>3D: Upload Photos <img src="../../Images/Preloader_3.gif" height="55" width="55"></h2>
  <table align="center" font size="6" border="1">
            <tr>
              <th style="text-align:center">File</th>
              <th style="text-align:center">Choose File</th> 
              <th style="text-align:center">Upload</th>
              <th style="text-align:center">Remove</th>
              <th style="text-align:center">Status</th>
            </tr>
            <tr>
              <form action="Upload_3D/Upload_v0.php" method="post" enctype="multipart/form-data">
                <td>File[0]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_3D/Remove_v0.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "../../../../BackEnd/Gallery/Images/Cubo3D/Image_V0/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
             </tr> 
             <tr>
              <form action="Upload_3D/Upload_v1.php" method="post" enctype="multipart/form-data">
                <td>File[1]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_3D/Remove_v1.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                     $dir = "../../../../BackEnd/Gallery/Images/Cubo3D/Image_V1/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
             </tr> 
             <tr>
              <form action="Upload_3D/Upload_v2.php" method="post" enctype="multipart/form-data">
                <td>File[2]: Select image to upload:</td>
                  <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_3D/Remove_v2.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "../../../../BackEnd/Gallery/Images/Cubo3D/Image_V2/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="Upload_3D/Upload_v3.php" method="post" enctype="multipart/form-data">
                <td>File[3]: Select image to upload:</td>
                <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_3D/Remove_v3.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                     $dir = "../../../../BackEnd/Gallery/Images/Cubo3D/Image_V3/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="Upload_3D/Upload_v4.php" method="post" enctype="multipart/form-data">
                <td>File[4]: Select image to upload:</td>
              <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_3D/Remove_v4.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "../../../../BackEnd/Gallery/Images/Cubo3D/Image_V4/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="Upload_3D/Upload_v5.php" method="post" enctype="multipart/form-data">
                <td>File[5]: Select image to upload:</td>
               <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_3D/Remove_v5.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "../../../../BackEnd/Gallery/Images/Cubo3D/Image_V5/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="Upload_3D/Upload_v6.php" method="post" enctype="multipart/form-data">
                <td>File[6]: Select image to upload:</td>
                      <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_3D/Remove_v6.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                     $dir = "../../../../BackEnd/Gallery/Images/Cubo3D/Image_V6/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
              <tr>
              <form action="Upload_3D/Upload_v7.php" method="post" enctype="multipart/form-data">
                <td>File[7]: Select image to upload:</td>
                    <td><input type="file" name="fileToUpload" id="fileToUpload"></td> 
                 <td><div align="center"><input type="image" src="../../Images/Upload.jpg" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                  <form action="remove_upload_3D/Remove_v7.php" method="post">
                  <td><div align="center"><input type="image" src="../../Images/RemoveFile.ico" width="30"  height="30" boder="0" alt="SUBMIT!"></div></td></form>
                <?PHP
                    $dir = "../../../../BackEnd/Gallery/Images/Cubo3D/Image_V7/";
                    $scan = scandir($dir);
                    if(count($scan) > 2)echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/not_available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                    else echo " <td><div align=\"center\"><input type=\"image\" src=\"../../Images/Available.png\" width=\"30\"  height=\"30\" boder=\"0\" alt=\"SUBMIT!\"></div></td>\n";
                ?>
              </tr> 
             
          <table>
</div>
      <!-- Example row of columns -->
      <div class="row">
        <div class="col-lg-4">
          <h2>Safari bug warning!</h2>
          <p class="text-danger">As of v9.1.2, Safari exhibits a bug in which resizing your browser horizontally causes rendering errors in the justified nav that are cleared upon refreshing.</p>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
        </div>
        <div class="col-lg-4">
          <h2>Heading</h2>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
       </div>
        <div class="col-lg-4">
          <h2>Heading</h2>
          <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa.</p>
          <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
        </div>
      </div>
      <!-- Site footer -->
      <footer class="footer">
        <p>&copy; 2016 Company, Inc.</p>
      </footer>

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../Layout/js/assets/ie10-viewport-bug-workaround.js"></script>
</body>
</html>