
<?php
//Connections
include '../../../Conn/Conn.php';

//Getting values
$UpdateInfo = $_POST['UpdateInfo'];
$newfield = $_POST['newfield'];
$Username = $_GET['user'];
//Check Empty field newfield
if(empty($newfield))
{
        echo "<script>alert(\" The New field is found empty. Please fill it.\")</script>";
        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../InfoAdmin/InfoAdmin.php\";
        }redireciona();
        </script>";
}
else
{
        //Update Field
         $sql_updatfield = "UPDATE Login SET $UpdateInfo = '" . $newfield . "' WHERE Username = '" . $Username . "'";
        if (mysqli_query($conn, $sql_updatfield)) {
                echo "<script>alert(\" The '".$UpdateInfo."'  has been updated successfully\")</script>";
                echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../InfoAdmin/InfoAdmin.php\";
                }redireciona();
                </script>";
        } else {
                echo "<script>alert(\" The '".$UpdateInfo."' NOT has been updated\")</script>";
                echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../InfoAdmin/InfoAdmin.php\";
                }redireciona();
                </script>";
                
        }
        
}
  




?>




