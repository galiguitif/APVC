<?PHP include '../../../Conn/Session_MProject.php'; ?>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="initial-scale=1.0, maximum-scale=2.0">
	
    <!-- Bootstrap core CSS -->
    <link href="../../Layout/css/dist/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../../Layout/css/assets/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="justified-nav.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../Layout/js/assets/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

     <!-- Panel -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!--Panel -->


	<link rel="stylesheet" type="text/css" href="layout/media/css/jquery.dataTables.css">
	<link rel="stylesheet" type="text/css" href="layout/css/buttons.dataTables.css">
	<link rel="stylesheet" type="text/css" href="layout/resources/syntax/shCore.css">

	<style type="text/css" class="init">
	
	</style>
	<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.12.4.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/media/js/jquery.dataTables.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/js/dataTables.buttons.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/js/buttons.flash.js">
	</script>
	<script type="text/javascript" language="javascript" src="//cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/pdfmake.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/vfs_fonts.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/js/buttons.html5.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/js/buttons.print.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/examples/resources/syntax/shCore.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/examples/resources/demo.js">
	</script>
	<script type="text/javascript" language="javascript" class="init">
	
$(document).ready(function() {
	$('#example').DataTable( {
		dom: 'Bfrtip',
		buttons: [
			'copy', 'csv', 'excel', 'pdf', 'print'
		]
	} );
} );
	</script>
</head>
<body class="dt-example">
    <div class="container">
      <!-- The justified navigation menu is meant for single line per list item.
           Multiple lines will require custom code not provided by Bootstrap. -->
      <div class="masthead">
	        <h3 class="text-muted">Project name</h3>
        <nav>
          <ul class="nav nav-justified">
            <li><a href="../index.php">Home</a></li>
             <li class="active"><a href="#">InfoUsers</a></li>
            <li><a href="../InfoAdmin/InfoAdmin.php">Services</a></li>
            <li><a href="../PaymentControl/PaymentControl.php">PaymentControl</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
        </nav>
      </div>
<br>
    </div>
	<div class="container">
		<section>
			<table id="example" class="display nowrap" cellspacing="0" width="100%">
			    <?PHP
include '../../../Conn/conn.php';
$Username=$_GET['Username'];
$sql    = "Select Name,Surname,Username,City,Email,Phone,Age,Payment from Login where Username='".$Username."' ";
$result = $conn->query($sql);
print '<thead>';
print '<tr>';
print '<th>Choose:</th>';
print '<th>Name</th>';
print '<th>Surname</th>';
print '<th>Username</th>';
print '<th>City</th>';
print '<th>Email</th>';
print '<th>Phone</th>';
print '<th>Age</th>';
print '<th>Payment</th>';
print '</tr>';
print '</thead>';
print '<tfoot>';
print '<tr>';
print '<th>Choose:</th>';
print '<th>Name</th>';
print '<th>Surname</th>';
print '<th>Username</th>';
print '<th>City</th>';
print '<th>Email</th>';
print '<th>Phone</th>';
print '<th>Age</th>';
print '<th>Payment</th>';
print '</tr>';
print '</tfoot>';
print '<tbody>';
if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {
        print '<tr>';
        $GET_Username=$row['Username'];
        print '<td>'."<a href=../InfoAdmin/InfoAdmin.php><img src=\"../../Images/Back.jpg\" alt=\"Smiley face\" height=\"25\" width=\"25\"></a>\n". '</td>';
        foreach ($row as $item) {
            print '<td>' . ($item !== null ? htmlentities($item, ENT_QUOTES) : '&nbsp') . '</td>';
          
        }
        print '</tr>';
    }
}

print '</tbody>';
?>	
<br>

</table>
</section>
<br>
<br>
<br>
 <div class="panel panel-primary">
  <div class="panel-heading">Look Information about User</div>
   <div class="panel-body">
  <form>
     <div class="form-group">
      <label for="name">Username</label>
      <input type="text" class="form-control" name="Username" id="Username" placeholder=<?PHP print($_GET['Username']); ?> disabled>
    </div>
    <div class="form-group">
      <label for="name">Name</label>
      <input disabled type="text" class="form-control" name="Name" id="Name" placeholder=<?PHP
        include '../../../Conn/conn.php';
        $Username=$_GET['Username'];
        $sql    = "Select Id,Name,Surname,Username,City,Email,Phone,Age from Login where Username='".$Username."'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          echo $Name=$row['Name'];}
        }?>>
    </div>
    <div class="form-group">
      <label for="Surname">Surname</label>
      <input disabled type="text" class="form-control" name="Surname" id="Surname" placeholder=<?PHP
        include '../../../Conn/conn.php';
        $Username=$_GET['Username'];
        $sql    = "Select Id,Name,Surname,Username,City,Email,Phone,Age from Login where Username='".$Username."'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          echo $Surname=$row['Surname'];}
        }?>>
    </div>
    <div  class="form-group">
     <label for="age">Age</label>
      <input disabled type="text" class="form-control" name="age" id="age" placeholder=<?PHP
        include '../../../Conn/conn.php';
        $Username=$_GET['Username'];
        $sql    = "Select Id,Name,Surname,Username,City,Email,Phone,Age from Login where Username='".$Username."'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          echo $Age=$row['Age'];}
        }?>>
    </div>
    <div  class="form-group">
      <label for="city">City</label>
      <input disabled type="text" class="form-control" name="city" id="city" placeholder=<?PHP
        include '../../../Conn/conn.php';
        $Username=$_GET['Username'];
        $sql    = "Select Id,Name,Surname,Username,City,Email,Phone,Age from Login where Username='".$Username."'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          echo $City=$row['City'];}
        }?>>
    </div>
    <div  class="form-group">
     <label for="phone">Phone</label>
     <input disabled type="text" class="form-control" name="phone" id="phone" placeholder=<?PHP
        include '../../../Conn/conn.php';
        $Username=$_GET['Username'];
        $sql    = "Select Id,Name,Surname,Username,City,Email,Phone,Age from Login where Username='".$Username."'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          echo $Phone=$row['Phone'];}
        }?>>
    </div>
    <div  class="form-group">
      <label for="email">Email</label>
      <input disabled type="text" class="form-control" name="email" id="email" placeholder=<?PHP
        include '../../../Conn/conn.php';
        $Username=$_GET['Username'];
        $sql    = "Select Email from Login where Username='".$Username."'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          echo $Email=$row['Email'];}
        }?>>
    </div>

        <div  class="form-group">
      <label for="Payment">Payment</label>
      <input disabled type="text" class="form-control" name="Payment" id="Payment" placeholder=<?PHP
        include '../../../Conn/conn.php';
        $Username=$_GET['Username'];
        $sql    = "Select Payment from Login where Username='".$Username."'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          echo $Payment=$row['Payment'];}
        }?>>
    </div>

       <div  class="form-group">
      <label for="Calendar">Date Record</label>
      <input disabled type="text" class="form-control" name="Calendar" id="Calendar" placeholder=<?PHP
        include '../../../Conn/conn.php';
        $Username=$_GET['Username'];
        $sql    = "Select Calendar from Login where Username='".$Username."'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          echo $Calendar=$row['Calendar'];}
        }?>>
    </div>
</form>
      </div>
    </div>
<br>
<br>
<?PHP
$Username=$_GET['Username'];
print "<form action=\"UpdateInfo.php?user=$Username\" method=\"POST\">\n"; 
print "  <div class=\"container\">\n"; 
print "<h2>Update Information <img  src=\"../../Images/Editor.png\" width='45' height='45' data-toggle=\"modal\" data-target=\".bs-example-modal-sm\"></img></h2>\n" ;

print "    <div class=\"panel-group\">\n"; 
print "    <div class=\"panel panel-success\">\n"; 
print "    <div class=\"panel-heading\">Information</div>\n"; 
print "    <div class=\"panel-body\">   \n"; 
print "\n"; 
print "     <div class=\"form-group\">\n"; 
print "      <label for=\"name\">Username</label>\n"; 
print "      <input type=\"text\" class=\"form-control\" name=\"Username\" id=\"Username\" placeholder=$Username disabled>\n"; 
print "    </div>\n"; 
print "\n"; 
print "    What do tou want change? <select name=\"UpdateInfo\">\n"; 
print "    <option value=\"Name\">Name</option>\n"; 
print "    <option value=\"Surname\">Surname</option>\n"; 
print "    <option value=\"Age\">Age</option>\n"; 
print "    <option value=\"City\">City</option>\n"; 
print "    <option value=\"Phone\">Phone</option>\n"; 
print "    <option value=\"Email\">Email</option>\n"; 
print "    <option value=\"Payment\">Payment</option>\n"; 
print "     </select>\n"; 
print "     <br> <br>\n"; 
print "      <div class=\"form-group\">\n"; 
print "       <label for=\"name\">New Update</label>\n"; 
print "       <input type=\"text\" class=\"form-control\" name=\"newfield\" id=\"newfield\" placeholder=\"New field\">\n"; 
print "      </div>\n"; 
print "      <div align=\"center\"><button type=\"submit\" class=\"btn btn-primary\">New Update</button> <button type=\"reset\" class=\"btn btn-primary\">Clear Fields</button>  </div>\n"; 
print "</form>\n";

?>
</div>
</div>    
</div>
</div>




      <!-- Example row of columns -->
      <div class="row">
        <div class="col-lg-4">
          <h2>Safari bug warning!</h2>
          <p class="text-danger">As of v9.1.2, Safari exhibits a bug in which resizing your browser horizontally causes rendering errors in the justified nav that are cleared upon refreshing.</p>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
        </div>
        <div class="col-lg-4">
          <h2>Heading</h2>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
       </div>
        <div class="col-lg-4">
          <h2>Heading</h2>
          <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa.</p>
          <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
        </div>
      </div>
      <!-- Site footer -->
      <footer class="footer">
        <p>&copy; 2016 Company, Inc.</p>
      </footer>
    </div> <!-- /container -->
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../Layout/js/assets/ie10-viewport-bug-workaround.js"></script>
</body>
</html>