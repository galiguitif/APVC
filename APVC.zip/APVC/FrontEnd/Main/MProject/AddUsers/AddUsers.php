<?PHP include '../../../Conn/Session_MProject.php'; ?>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="initial-scale=1.0, maximum-scale=2.0">
	
    <!-- Bootstrap core CSS -->
    <link href="../../Layout/css/dist/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../../Layout/css/assets/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="justified-nav.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../Layout/js/assets/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

     <!-- Panel -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!--Panel -->


	<link rel="stylesheet" type="text/css" href="layout/media/css/jquery.dataTables.css">
	<link rel="stylesheet" type="text/css" href="layout/css/buttons.dataTables.css">
	<link rel="stylesheet" type="text/css" href="layout/resources/syntax/shCore.css">

	<style type="text/css" class="init">
	
	</style>
	<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.12.4.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/media/js/jquery.dataTables.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/js/dataTables.buttons.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/js/buttons.flash.js">
	</script>
	<script type="text/javascript" language="javascript" src="//cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/pdfmake.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/vfs_fonts.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/js/buttons.html5.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/js/buttons.print.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/examples/resources/syntax/shCore.js">
	</script>
	<script type="text/javascript" language="javascript" src="layout/examples/resources/demo.js">
	</script>
	<script type="text/javascript" language="javascript" class="init">
	
$(document).ready(function() {
	$('#example').DataTable( {
		dom: 'Bfrtip',
		buttons: [
			'copy', 'csv', 'excel', 'pdf', 'print'
		]
	} );
} );
	</script>
</head>
<body class="dt-example">

    <div class="container">
      <!-- The justified navigation menu is meant for single line per list item.
           Multiple lines will require custom code not provided by Bootstrap. -->
      <div class="masthead">
	        <h3 class="text-muted">Project name</h3>
        <nav>
          <ul class="nav nav-justified">
            <li><a href="../index.php">Home</a></li>
             <li class="active"><a href="#">InfoUsers</a></li>
            <li><a href="#">Services</a></li>
            <li><a href="#">Downloads</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
        </nav>
      </div>
<br>
    </div>
	<div class="container">

 <div class="panel panel-primary">
  <div class="panel-heading">New User</div>
   <div class="panel-body">
     
  <form action="NewRecord.php" method="POST">
    <div class="form-group">
      <label for="name">Name</label>
      <input type="text" class="form-control" name="Name" id="Name" placeholder="Name">
    </div>
    <div class="form-group">
      <label for="Surname">Surname</label>
      <input type="text" class="form-control" name="Surname" id="Surname" placeholder="Surname">
    </div>
    <div class="form-group">
      <label for="Username">Username</label>
      <input type="text" class="form-control" name="Username" id="Username" placeholder="Username">
    </div>
    <div class="form-group">
      <label for="SecretPassword">SecretPassword</label>
      <input type="password" class="form-control" name="SecretPassword" id="SecretPassword" placeholder="SecretPassword">
    </div>
    <div class="form-group">
      <label for="Password">Password</label>
     <input type="password" class="form-control" name="Password" id="Password" placeholder="Password">
    </div>
    <div class="form-group">
      <label for="RPassword">Repeat Password</label>
      <input type="password" class="form-control" name="RPassword" id="RPassword" placeholder="Repeat Password">
    </div>
    <div class="form-group">
     <label for="age">Age</label>
      <input type="text" class="form-control" name="age" id="age" placeholder="age">
    </div>
    <div class="form-group">
      <label for="city">City</label>
      <input type="text" class="form-control" name="city" id="city" placeholder="city">
    </div>
    <div class="form-group">
     <label for="phone">Phone</label>
     <input type="text" class="form-control" name="phone" id="phone" placeholder="phone">
    </div>
    <div class="form-group">
      <label for="email">Email</label>
      <input type="text" class="form-control" name="email" id="email" placeholder="email">
    </div>
      <div class="form-group"> 
         <label for="payment">Payment</label>
       <select name="Payment">
        <option value="Paid">Paid</option>
        <option value="Not Paid">Not Paid</option>
      </select></div>
    <div class="form-group">
      <label for="calendar">Calendar</label>
      <input type="date" name="Calendar" min="2000-01-02" placeholder="Calendar"><br><br>
     </div>
    <div align="center"><button type="submit" class="btn btn-primary">New Record</button> <button type="reset" class="btn btn-primary">Clear Fields</button>  </div>
</form>
      
      </div>
    </div>
<br>
<br>
      <!-- Example row of columns -->
      <div class="row">
        <div class="col-lg-4">
          <h2>Safari bug warning!</h2>
          <p class="text-danger">As of v9.1.2, Safari exhibits a bug in which resizing your browser horizontally causes rendering errors in the justified nav that are cleared upon refreshing.</p>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
        </div>
        <div class="col-lg-4">
          <h2>Heading</h2>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
       </div>
        <div class="col-lg-4">
          <h2>Heading</h2>
          <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa.</p>
          <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
        </div>
      </div>
      <!-- Site footer -->
      <footer class="footer">
        <p>&copy; 2016 Company, Inc.</p>
      </footer>
    </div> <!-- /container -->
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../Layout/js/assets/ie10-viewport-bug-workaround.js"></script>
</body>
</html>