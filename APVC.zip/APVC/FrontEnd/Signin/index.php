<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>APVC</title>

  <!--Collapsible-->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!--Collapsible-->

  <!--Panels -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!--Panels -->
   
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
  <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
  <link rel="stylesheet" href="Layout/css/style.css"> 
</head>
<body>
<div class="pen-title">
  <h1>APVC Vale Coronado </h1>
</div>

<!-- Form Module-->
<div class="module form-module">
  <div class="toggle"><i class="fa fa-times fa-pencil"></i>
    <div class="tooltip">Click Me</div>
  </div>
  <div class="form">
    <h2>Login to your account</h2>
    <form  action='CheckLogin/CheckLogin.php' method="POST">
      <input type="text" name="Username" placeholder="Username"/>
      <input type="password" name="Password" placeholder="Password"/>
      <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
    </form>
  </div>
  <div class="form">
    <h2>Create an account</h2>
    <form action="NewRecord/NewRecord.php" method="POST">
      <input type="text" name="Name" placeholder="Name"/>
      <input type="text" name="Surname" placeholder="Surname"/>
      <input type="text" name="Username" placeholder="Username"/>
       <input type="password" name="SecretPassword" placeholder="Secret Password"/>
      <input type="password" name="Password" placeholder="Password"/>
      <input type="password" name="RPassword" placeholder="Repeat Password"/>
      <input type="text" name="age" placeholder="age"/>
      <input type="text" name="city" placeholder="City"/>
      <input type="text" name="phone" placeholder="Phone : +351 [xxxxxxxxx]"/>
      <input type="text" name="email" placeholder="Email : example@gmail.com"/>
      <input type="text" name="Payment" placeholder="Payment" disabled/>
      <div align="center"> <select name="Payment">
        <option value="Paid">Paid</option>
        <option value="Not Paid">Not Paid</option>
      </select></div>
      <br>
      <br>
      <input type="text"  name="Calendar" placeholder="Calendar" disabled/>
      <input type="date" name="Calendar" min="2000-01-02" placeholder="Calendar"><br><br>
      <br>
      <br>
      <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
    </form>
  </div>
  <div class="cta" data-toggle="collapse" data-target="#demo">Forgot your password?</div>
  <div id="demo" class="collapse">
    <div class="panel panel-info">
      <div class="panel-heading">Recover Password</div>
      <div class="panel-body">If you forget your password, please contact the admin. Thank you.</div>
    </div>
  </div>
</div>
</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='https://codepen.io/andytran/pen/vLmRVp.js'></script>
<script src="Layout/js/index.js"></script>
</body>
</html>
