<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>APVC</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <div class="login">
  <div class="login-triangle"></div>
    <h2 class="login-header">APVC</h2>

  <form class="login-container" action="CheckLogin/CheckLogin.php" method="POST">
    <p><input type="text" name="Username" placeholder="Username"></p>
    <p><input type="password" name="Password" placeholder="Password"></p>
    <p><input type="submit"  value="Log in"></p>
  </form>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  
</body>
</html>
