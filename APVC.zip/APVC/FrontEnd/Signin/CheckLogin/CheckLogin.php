<?php
include '../../Conn/Conn.php';

// Getting Username and Posto from index.php page
$user = $_POST['Username'];
$pass = $_POST['Password'];
//Encryption Password
$passwordencryption=sha1($pass);
//Check fields empty or not
if( empty($user) || empty($pass))
{
    echo "<script>alert(\"Some fields are empty, please you should fill them.\")</script>";
    echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../index.php\";
    }redireciona();
    </script>";  
}

//Check Already exist user
$CheckUser = "Select * From login where Username = '".$user."' and Password='".$passwordencryption."'";
$result = $conn->query($CheckUser);

//Exist Results
if ($result->num_rows > 0) {
   session_start();
   $_SESSION['logged_user'] = $user;
   $_SESSION['enc_pass'] = $passwordencryption;
   header("Location: ../../Main/MProject/index.php?user=".$user);
}
else
{
    echo "<script>alert(\"The user doesn't exist. Please , you must make sign up\")</script>";
    echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../index.php\";
    }redireciona();
    </script>";
}

?> 



