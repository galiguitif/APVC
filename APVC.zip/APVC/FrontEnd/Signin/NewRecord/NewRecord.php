<?php
include '../../Conn/Conn.php';

// Getting Username and Posto from index.php page
$name = $_POST['Name'];
$surname = $_POST['Surname'];
$user = $_POST['Username'];
$pass = $_POST['Password'];
$rpass = $_POST['RPassword'];
$city = $_POST['city'];
$age = $_POST['age'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$SecretPassword = $_POST['SecretPassword'];
$payment=$_POST['Payment'];
$calendar=$_POST['Calendar'];

//Check fields empty or not
if(empty($payment) ||empty($calendar) || empty($name) || empty($surname) || empty($user) || empty($SecretPassword)|| empty($pass) || empty($rpass)|| empty($city) || empty($age) || empty($phone) || empty($email))
{
    echo "<script>alert(\"Some fields are empty, please you should fill them.\")</script>";
    echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../index.php\";
    }redireciona();
    </script>";  
}
else
{
            $Secretpasswordencryption=sha1($SecretPassword);
            //Check SecretPassword
            $CheckSecretPassword = "Select * From SecretPassword where SecretPassword = '".$Secretpasswordencryption."'";
            $result_SecretPassword = $conn->query($CheckSecretPassword);

            //Exist Results
            if ($result_SecretPassword->num_rows > 0) {
                //Check if email is valid
                if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        //Check Already exist user
                        $CheckUser = "Select * From login where Username = '".$user."'";
                        $result = $conn->query($CheckUser);

                        //Exist Results
                        if ($result->num_rows > 0) {
                                echo "<script>alert(\"The username already exist , please introduce another user.\")</script>";
                                echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../index.php\";
                                }redireciona();
                                </script>";
                        }
                        else
                        {
                        //Check if passwords are different
                        if($pass!=$rpass)
                        {
                            echo "<script>alert(\"The Passwords are different.\")</script>";
                            echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../index.php\";
                            }redireciona();
                            </script>";  
                        }

                            //Encryption Password
                            $passwordencryption=sha1($pass);

                            //Insert New record
                            $newrecord = "INSERT INTO Login (Name, Surname,Username, Password,city,age,phone,email,Payment,Calendar)
                            VALUES ('".$name."','".$surname."','".$user."','" .$passwordencryption."','" .$city."','" .$age."','" .$phone."','" .$email."','" .$payment."','" .$calendar."')";
                            
                            if ($conn->query($newrecord) === TRUE) {

                            //Insert Payment Control
                            $paymentControl = "INSERT INTO paymentcontrol (Username,Year,Phone,Email,Paid)
                            VALUES ('".$user."','".$calendar."','" .$phone."','" .$email."','" .$payment."')";
                                if ($conn->query($paymentControl) === TRUE) {

                                echo "<script>alert(\"New record created successfully\")</script>";
                                echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../index.php\";
                                }redireciona();
                                </script>";
                                }
                                else print "Error: " . $paymentControl . "<br>" . $conn->error;
                            } else print "Error: " . $newrecord . "<br>" . $conn->error;
                        }
                    } else {
                        echo "<script>alert(\"It is not  valid email address\")</script>";
                        echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../index.php\";
                        }redireciona();
                        </script>";  
                    }
            }
            else
            {
                echo "<script>alert(\"The Secret Password is wrong, please tou must to contact Administrator\")</script>";
                echo "<script language=\"JavaScript\">function redireciona() {window.location=\"../index.php\";
                }redireciona();
                </script>";    
            }
}

?> 



