<?PHP
session_start();

if (!isset($_SESSION['logged_user']) or !isset($_SESSION['enc_pass']))
{
    session_destroy();
    header('location:../Signin/index.php');
}
else
{
        include 'Conn.php';
        $user = $_SESSION['logged_user'];
        $pass = $_SESSION['enc_pass'];
        $sql = "Select * From login where Username = '".$user."' and Password = '".$pass."'";
        $result = mysqli_query($conn,$sql);
        $n_rows = mysqli_num_rows($result);
        if ($n_rows!=1)
        {
            session_destroy();
           header('location:../Signin/index.php');
        } 
}
?>