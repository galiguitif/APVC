<?php
session_start();
session_destroy();
$_SESSION['logged_user'] = '';
$_SESSION['enc_pass'] = '';
header("Location: ../Signin/index.php");
?>